﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace examenunidad1fredyvasquez
{
    internal class Ejercicio_3
    {
        Random random = new Random();
        public Ejercicio_3()
        {
            Console.WriteLine("Ingrese el numero de filas que desea en su matriz:");
            int filas = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el numero de columnas que desea en su matriz:");
            int columnas = int.Parse(Console.ReadLine());

            int filasT = filas + 1;
            int columnasT = columnas + 1;

            int[,] matriz = new int[filasT, columnasT];

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    matriz[i, j] = random.Next(1,100);
                    Console.WriteLine(matriz[i, j]);

                    //sumFilas+= matriz[i, j];
                    //sumColumnas+= matriz[i, j];

                }
            }

            for (int i = 0; i < filas; i++)
            {

                for (int j = 0; j < columnas; j++)
                {
                    matriz[i, columnas] = matriz[i, j] + matriz[i, j + 1];
                    i++;
                }
                Console.WriteLine(matriz[i, columnas]);
            }
        }
    }
}
